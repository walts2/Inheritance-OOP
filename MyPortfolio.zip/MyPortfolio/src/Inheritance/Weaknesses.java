package Inheritance;

public class Weaknesses {
	
	public String weakness1 = "Easily stressed";
	public String weakness2 = "Not a great speaker";
	public String weakness3 = "Easily distracted";

}
