package Inheritance;

public class Hobby extends Skills {
	
	public String hobby1 = "Playing online and video games";
	public String hobby2 = "Listening to music";
}
