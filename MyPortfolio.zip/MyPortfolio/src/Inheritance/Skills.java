package Inheritance;

public class Skills extends Strengths {
	
	public String Skills = "Photography, using a digital camera";

}
