package Inheritance;

public class AboutMe {
		
		public String name = "Elaine Grace C. Victoria";
		public String nickname = "Walt";
		public String birthday = "January 31, 2000";
		public String age = "23"; 
		public String address = "17 St Paul St Villa Espana Subdivision Araneta Ave";
		public String height = "5'0";
		public String weight = "47 kg";
	}
