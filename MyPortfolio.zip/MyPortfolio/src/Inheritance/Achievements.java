package Inheritance;

public class Achievements extends AboutMe {
	
	public String achievement = "Representative for entrep mind campus-wide pitching";
	public String product = "Our product: Prosera Safety Bracelet";

}
