package Inheritance;

public class ContactMe extends Achievements {
	
	public String phoneNum = "09263820015";
	public String email = "elaine_onki@yahoo.com";
	public String fbname = "Elaine Victoria";

}
