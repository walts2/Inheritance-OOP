package Inheritance;

public class Strengths extends Weaknesses {
	
	public String strength1 = "Reliable";
	public String strength2 = "Independent";
	public String strength3 = "Good Observer";

}
