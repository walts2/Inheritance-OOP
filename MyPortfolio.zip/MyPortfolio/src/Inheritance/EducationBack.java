package Inheritance;

public class EducationBack extends Hobby {
	
	public String year1 = "2005 - 2016";
	public String school1 = "Immaculate Heart of Mary College";
	public String yearlevel = "Elementary to Highschool";
	public String year2 = "2016 - 2018";
	public String school2 = "STI College Recto";
	public String yearlevel1 = "Senior High School";

}
